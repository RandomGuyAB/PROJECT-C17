var PLAY = 1;
var END = 0;
var gameState = 1;
var Sword, Fruits, Enemy;
function preload(){

SwordImage = loadImage("sword.png")
}
function setup(){
Sword = createSprite(40,200,20,20);
Sword.addImage(SwordImage);
  
Sword.scale = 0.7;
  
  
}



function draw(){
if (gameState === PLAY) {
Sword.y = World.mouseY;
Sword.x = World.mouseX
  
  
}
}

